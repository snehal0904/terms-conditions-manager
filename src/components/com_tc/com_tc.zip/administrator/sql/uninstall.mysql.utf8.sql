DROP TABLE IF EXISTS `#__tc_content`;

DROP TABLE IF EXISTS `#__tc_patterns`;

DROP TABLE IF EXISTS `#__tc_acceptance`;

